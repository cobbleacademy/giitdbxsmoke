# ws-2-examples

Fictitious use cases that show how Git repos, bundles and workspace folders line up across orgs, BUs and environments
(dev, test, prod). Everything here is invented; the org and BU names only echo the deck.

## The rules the examples follow

| Thing | Rule | Example |
|---|---|---|
| Workspace | `<org>-<env>`, one per org and environment | `ocio-dev`, `ocio-test`, `ocio-prod` |
| Use case repo | `<org>-<bu>-<usecase>[-<purpose>]`; one repo per use case, a purpose suffix only for a separate release cycle | `ocio-im50-uap`, `ocio-im60-watchtower-ml` |
| Shared repo | `<org>-shared-libs`, one per org | `ocio-shared-libs` |
| Bundle | one per repo, named after the repo; holds src, yml, py, notebooks, pipelines and build files together | `databricks.yml` at the repo root |
| Deployed folder | `/Workspace/Shared/<bu>/<usecase>` in every workspace of the org (`/Workspace/Shared/shared-libs` for shared code) | `/Workspace/Shared/im50/uap` |
| Developer folder | user Git folder, dev only | `/Workspace/Users/<user>/<repo>` |
| Catalog written to | `<bu>_<env>` | `im50_dev` |

## Orgs, BUs and use cases

| Org | BU | Repo | What it shows |
|---|---|---|---|
| ocio | im50 | `ocio-im50-uap` | One use case, several purposes in one bundle: wheel task, pipeline, notebook task and a Databricks app |
| ocio | im60 | `ocio-im60-watchtower` | Notebook-led reporting from system tables, a SQL task, small tested Python rules |
| ocio | im60 | `ocio-im60-watchtower-ml` | Same use case split into its own repo (own owner and release cycle): wheel entry points `train` and `score` |
| ocio | all | `ocio-shared-libs` | Wheel `ocio_common` read by the other OCIO bundles |
| cmei | aso | `cmei-aso-grants-reporting` | Pipeline, `spark_python_task` and notebook task in one job; Spark tests |
| cmei | epo | `cmei-epo-doc-intake` | Auto Loader pipeline on a landing volume, filename rules in plain Python used as a UDF |
| cmei | all | `cmei-shared-libs` | Wheel `cmei_common` |
| gc | gc30 | `gc-gc30-foia-tracking` | Pipeline, wheel task and notebook; SLA rules in plain Python |
| gc | all | `gc-shared-libs` | Wheel `gc_common` |

`examples.yaml` is the generated inventory of the same information.

## Folder map

```
ws-2-examples/
  repos/<repo>/              the Git repos (what lives in GitHub)
    databricks.yml           bundle with dev, test and prod targets, one per org-env workspace
    pyproject.toml           wheel build
    resources/*.yml          jobs, pipelines, apps
    src/<package>/           Python package (wheel)
    src/notebooks|pipelines|jobs|sql|app/
    tests/                   unit tests
    .github/workflows/       ci.yml (pull requests) and deploy.yml (test after merge, prod after approval)
  workspaces/<org>-<env>/Workspace/
    Users/<user>/<repo>/     dev only: the developer's Git folder (full checkout)
    Shared/<bu>/<usecase>/   files/ (synced bundle files), artifacts/, state/  (dev, test and prod)
    Shared/shared-libs/      the org's shared wheel, readable by every BU in that workspace
  tools/                     generator, deploy simulator and validator
```

`workspaces/` is a simulation of what `databricks bundle deploy` would leave in each workspace, built by
`tools/simulate_deploy.py` from the repos. Test and prod have no `Users` folder, so nothing there is edited by hand.

## How the flow maps to the folders

1. Branch `<ticket>-desc` in your Git folder under `workspaces/<org>-dev/Workspace/Users/...`.
2. Pull request: `ci.yml` runs the tests and `databricks bundle validate -t dev`.
3. Merge to main: `deploy.yml` deploys the `test` target to `<org>-test`.
4. The `<org>-prod` GitHub Environment needs a reviewer, then `deploy.yml` deploys the `prod` target to `<org>-prod`.
5. Cross-BU reuse: bundles install `ocio_common` (or `cmei_common`, `gc_common`) from
   `/Workspace/Shared/shared-libs/artifacts/...`, a folder only the shared-libs deploy principal writes.

## Commands

```bash
make setup      # venv with pyspark, pytest, pyyaml
make all        # generate repos, simulate deploys, validate, run all unit tests
```

## What is and is not verified

Checked on this machine (`make all`): repo and bundle naming, targets, host and root paths per org-env, catalog names,
file references in every job and pipeline, entry points, shared-library wiring, CI and deploy workflow shape,
the simulated workspace tree mirroring each repo, and 24 unit tests (Spark tests for `uap` and `grants`).

Not run anywhere: `databricks bundle validate` or `deploy`, the pipelines, notebooks, app and workflows. Bundle fields
(`apps`, `environments`, wheel dependencies from a workspace path, `github-oidc` auth) are written from the documented
schema and need a first validate against a real workspace. Replace the `REPLACE-*` hosts, IDs and policy placeholders first.
