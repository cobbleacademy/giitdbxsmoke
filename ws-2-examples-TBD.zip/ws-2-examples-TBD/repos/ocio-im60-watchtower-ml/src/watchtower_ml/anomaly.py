import statistics


def baseline(values):
    """Mean and standard deviation of a history of daily costs."""
    if len(values) < 2:
        raise ValueError("need at least two days of history")
    return statistics.mean(values), statistics.pstdev(values)


def zscore(value, mean, std):
    return 0.0 if std == 0 else (value - mean) / std


def flag_anomalies(values, mean, std, threshold=3.0):
    """Indexes of days whose cost is more than `threshold` standard deviations from the baseline."""
    return [i for i, v in enumerate(values) if abs(zscore(v, mean, std)) > threshold]
