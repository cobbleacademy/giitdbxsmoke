import argparse

from ocio_common.logging_setup import get_logger
from watchtower_ml.anomaly import baseline, flag_anomalies

log = get_logger("watchtower_ml")


def _args(argv):
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    return parser.parse_args(argv)


def train(argv=None):
    from pyspark.sql import SparkSession

    args = _args(argv)
    spark = SparkSession.builder.getOrCreate()
    costs = [r["daily_cost"] for r in spark.table(f"{args.catalog}.watchtower_gold.daily_cost").collect()]
    mean, std = baseline(costs)
    log.info("trained on %d days: mean=%.2f std=%.2f", len(costs), mean, std)
    spark.createDataFrame([(mean, std)], "mean double, std double").write.mode("overwrite").saveAsTable(f"{args.catalog}.watchtower_gold.cost_baseline")


def score(argv=None):
    from pyspark.sql import SparkSession

    args = _args(argv)
    spark = SparkSession.builder.getOrCreate()
    base = spark.table(f"{args.catalog}.watchtower_gold.cost_baseline").first()
    costs = [r["daily_cost"] for r in spark.table(f"{args.catalog}.watchtower_gold.daily_cost").orderBy("usage_date").collect()]
    flagged = flag_anomalies(costs, base["mean"], base["std"])
    log.info("anomalous days: %s", flagged)
