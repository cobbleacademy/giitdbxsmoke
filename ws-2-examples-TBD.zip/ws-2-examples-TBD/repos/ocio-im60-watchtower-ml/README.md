# ocio-im60-watchtower-ml

Watchtower ML: weekly baseline training and daily scoring of cost anomalies, released separately from the reporting repo

- Org: `ocio`  |  BU: `im60`  |  Use case: `watchtower`
- Workspaces: `ocio-dev`, `ocio-test`, `ocio-prod`
- Deployed folder: `/Workspace/Shared/im60/watchtower-ml` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the watchtower_ml wheel (entry points: train, score)
resources/                jobs.yml
src/watchtower_ml/        anomaly.py (pure Python), cli.py
tests/                    anomaly tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `ocio-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `ocio-test`; the `ocio-prod` environment needs an approver before the prod deploy.

Split from ocio-im60-watchtower because the model has its own owner and release cycle; both deploy under the same BU folder tree.
