import pytest

from watchtower_ml.anomaly import baseline, flag_anomalies, zscore


def test_baseline_needs_history():
    with pytest.raises(ValueError):
        baseline([10.0])


def test_zscore_handles_flat_history():
    assert zscore(5.0, 5.0, 0.0) == 0.0


def test_flag_anomalies_finds_the_spike():
    history = [100.0, 102.0, 98.0, 101.0, 99.0, 100.0]
    mean, std = baseline(history)
    assert flag_anomalies(history + [180.0], mean, std) == [6]
