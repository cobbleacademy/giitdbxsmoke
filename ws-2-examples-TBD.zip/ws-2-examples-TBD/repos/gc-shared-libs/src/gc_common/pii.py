def mask_email(email):
    """a.person@example.org -> a*****@example.org"""
    if not email or "@" not in email:
        return email
    local, domain = email.split("@", 1)
    return local[:1] + "*" * max(len(local) - 1, 1) + "@" + domain


def mask_phone(phone):
    """Keep only the last four digits."""
    digits = [c for c in (phone or "") if c.isdigit()]
    return "*" * max(len(digits) - 4, 0) + "".join(digits[-4:])
