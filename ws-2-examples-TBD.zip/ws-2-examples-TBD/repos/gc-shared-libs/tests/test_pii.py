from gc_common.pii import mask_email, mask_phone


def test_mask_email_keeps_first_letter_and_domain():
    assert mask_email("a.person@example.org") == "a*******@example.org"
    assert mask_email(None) is None


def test_mask_phone_keeps_last_four_digits():
    assert mask_phone("(202) 555-0147") == "******0147"
    assert mask_phone("") == ""
