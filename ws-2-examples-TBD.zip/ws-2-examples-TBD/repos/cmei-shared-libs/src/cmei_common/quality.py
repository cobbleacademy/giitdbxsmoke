def not_null_rate(rows, column):
    """Share of rows where `column` is present and not None. An empty input counts as 1.0."""
    if not rows:
        return 1.0
    return sum(1 for r in rows if r.get(column) is not None) / len(rows)
