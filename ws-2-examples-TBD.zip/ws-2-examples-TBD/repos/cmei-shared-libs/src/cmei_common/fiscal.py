from datetime import date


def fiscal_year(d: date) -> int:
    """US federal fiscal year: starts on 1 October of the previous calendar year."""
    return d.year + 1 if d.month >= 10 else d.year
