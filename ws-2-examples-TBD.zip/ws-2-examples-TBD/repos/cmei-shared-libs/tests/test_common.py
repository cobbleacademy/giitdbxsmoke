from datetime import date

from cmei_common.fiscal import fiscal_year
from cmei_common.quality import not_null_rate


def test_fiscal_year_rolls_over_in_october():
    assert fiscal_year(date(2026, 9, 30)) == 2026
    assert fiscal_year(date(2026, 10, 1)) == 2027


def test_not_null_rate():
    assert not_null_rate([{"a": 1}, {"a": None}, {"a": 2}, {"a": 3}], "a") == 0.75
