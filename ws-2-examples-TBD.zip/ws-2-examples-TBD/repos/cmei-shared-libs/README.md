# cmei-shared-libs

CMEI shared libraries: fiscal calendar and data quality helpers reused by every CMEI BU

- Org: `cmei`  |  Org-wide shared code, read by every BU of the org
- Workspaces: `cmei-dev`, `cmei-test`, `cmei-prod`
- Deployed folder: `/Workspace/Shared/shared-libs` in every workspace

## Layout

```
databricks.yml            bundle: publishes the cmei_common wheel for every BU of the org
pyproject.toml            builds the cmei_common wheel
src/cmei_common/          fiscal.py, quality.py
tests/                    unit tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `cmei-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `cmei-test`; the `cmei-prod` environment needs an approver before the prod deploy.

Other BUs read the published wheel from /Workspace/Shared/shared-libs/artifacts; only this repo's deploy principal writes there.
