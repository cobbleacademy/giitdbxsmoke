# ocio-im50-uap

Unified Analytics Platform: platform usage events ingested, cleaned and published as daily active users

- Org: `ocio`  |  BU: `im50`  |  Use case: `uap`
- Workspaces: `ocio-dev`, `ocio-test`, `ocio-prod`
- Deployed folder: `/Workspace/Shared/im50/uap` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the uap wheel
resources/                jobs.yml, pipelines.yml, app.yml
src/uap/                  transforms.py, cli.py (wheel entry point: ingest)
src/notebooks/            quality_check.py
src/pipelines/            uap_events.py
src/app/                  Databricks app (Streamlit)
tests/                    Spark transform tests
sample_data/              usage_events.csv
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `ocio-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `ocio-test`; the `ocio-prod` environment needs an approver before the prod deploy.

One use case, several purposes (ingest job, pipeline, quality notebook, app) in one bundle: they deploy together.
