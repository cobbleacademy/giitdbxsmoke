import os

from uap.transforms import clean_events, daily_active_users

SAMPLE = os.path.join(os.path.dirname(__file__), "..", "sample_data", "usage_events.csv")


def test_clean_events_drops_unattributable_rows(spark):
    raw = spark.read.option("header", True).csv(SAMPLE)
    cleaned = clean_events(raw)
    assert cleaned.count() == 4
    assert {r["event_type"] for r in cleaned.collect()} == {"login", "query"}


def test_daily_active_users_counts_distinct_users(spark):
    raw = spark.read.option("header", True).csv(SAMPLE)
    result = {str(r["event_date"]): r["active_users"] for r in daily_active_users(clean_events(raw)).collect()}
    assert result == {"2026-10-01": 2, "2026-10-02": 1}
