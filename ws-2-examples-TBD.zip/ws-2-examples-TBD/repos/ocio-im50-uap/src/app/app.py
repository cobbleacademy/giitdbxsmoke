import os

import pandas as pd
import streamlit as st
from databricks import sql

st.title("UAP daily active users")

with sql.connect(
    server_hostname=os.environ["DATABRICKS_HOST"],
    http_path=f"/sql/1.0/warehouses/{os.environ['DATABRICKS_WAREHOUSE_ID']}",
    credentials_provider=lambda: None,
) as conn:
    df = pd.read_sql(f"SELECT event_date, active_users FROM {os.environ['UAP_CATALOG']}.uap_gold.daily_active_users ORDER BY event_date", conn)

st.line_chart(df.set_index("event_date"))
