import argparse

from pyspark.sql import SparkSession, functions as F


def ingest(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--source_path", required=True)
    args = parser.parse_args(argv)
    spark = SparkSession.builder.getOrCreate()
    raw = spark.read.option("header", True).csv(args.source_path).withColumn("ingested_at", F.current_timestamp())
    raw.write.mode("append").saveAsTable(f"{args.catalog}.uap_bronze.usage_events_raw")
