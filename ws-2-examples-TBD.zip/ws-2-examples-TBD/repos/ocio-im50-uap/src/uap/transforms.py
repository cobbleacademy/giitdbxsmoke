from pyspark.sql import DataFrame, functions as F


def clean_events(df: DataFrame) -> DataFrame:
    """Trim ids, lower-case the event type, parse the timestamp and drop rows that cannot be attributed."""
    return (
        df.withColumn("user_id", F.trim("user_id"))
        .withColumn("event_type", F.lower(F.coalesce(F.trim("event_type"), F.lit("unknown"))))
        .withColumn("event_ts", F.to_timestamp("event_ts"))
        .filter(F.col("user_id").isNotNull() & (F.col("user_id") != "") & F.col("event_ts").isNotNull())
    )


def daily_active_users(events: DataFrame) -> DataFrame:
    return events.groupBy(F.to_date("event_ts").alias("event_date")).agg(F.countDistinct("user_id").alias("active_users"))
