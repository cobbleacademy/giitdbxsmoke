# Databricks notebook source
# MAGIC %md
# MAGIC # UAP quality check
# MAGIC Runs after the pipeline. Uses `ocio_common`, the org-wide shared library.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from ocio_common.quality import not_null_rate

rows = [r.asDict() for r in spark.table(f"{catalog}.uap_gold.daily_active_users").collect()]
rate = not_null_rate(rows, "active_users")
assert rate >= 0.99, f"active_users has too many nulls: {1 - rate:.2%}"
print("quality check passed")
