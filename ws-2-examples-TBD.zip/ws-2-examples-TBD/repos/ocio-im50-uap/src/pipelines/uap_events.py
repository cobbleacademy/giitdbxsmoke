import dlt
from uap.transforms import clean_events, daily_active_users

CATALOG = spark.conf.get("catalog")


@dlt.table(name=f"{CATALOG}.uap_silver.usage_events", comment="Cleaned platform usage events")
def usage_events():
    return clean_events(spark.read.table(f"{CATALOG}.uap_bronze.usage_events_raw"))


@dlt.table(name=f"{CATALOG}.uap_gold.daily_active_users", comment="Distinct active users per day")
def daily_active_users_table():
    return daily_active_users(spark.read.table(f"{CATALOG}.uap_silver.usage_events"))
