import pytest

from ocio_common.naming import parse_repo_name, workspace_name
from ocio_common.quality import not_null_rate


def test_not_null_rate():
    assert not_null_rate([{"a": 1}, {"a": None}], "a") == 0.5
    assert not_null_rate([], "a") == 1.0


def test_parse_repo_name_with_and_without_purpose():
    assert parse_repo_name("ocio-im50-uap") == {"org": "ocio", "bu": "im50", "usecase": "uap"}
    assert parse_repo_name("ocio-im60-watchtower-ml")["purpose"] == "ml"
    with pytest.raises(ValueError):
        parse_repo_name("IM50_UAP")


def test_workspace_name():
    assert workspace_name("ocio", "prod") == "ocio-prod"
    with pytest.raises(ValueError):
        workspace_name("ocio", "qa")
