import re

REPO = re.compile(r"^(?P<org>[a-z]+)-(?P<bu>[a-z0-9]+)-(?P<usecase>[a-z0-9]+)(?:-(?P<purpose>[a-z0-9]+))?$")


def parse_repo_name(name):
    """Split <org>-<bu>-<usecase>[-<purpose>] into its parts, or raise ValueError."""
    m = REPO.match(name)
    if not m:
        raise ValueError("not a use case repo name: " + name)
    return {k: v for k, v in m.groupdict().items() if v}


def workspace_name(org, env):
    if env not in ("dev", "test", "prod"):
        raise ValueError("unknown environment: " + env)
    return f"{org}-{env}"
