# ocio-shared-libs

OCIO shared libraries: data quality helpers, logging and naming rules reused by every OCIO BU

- Org: `ocio`  |  Org-wide shared code, read by every BU of the org
- Workspaces: `ocio-dev`, `ocio-test`, `ocio-prod`
- Deployed folder: `/Workspace/Shared/shared-libs` in every workspace

## Layout

```
databricks.yml            bundle: publishes the ocio_common wheel for every BU of the org
pyproject.toml            builds the ocio_common wheel
src/ocio_common/          quality.py, logging_setup.py, naming.py
tests/                    unit tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `ocio-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `ocio-test`; the `ocio-prod` environment needs an approver before the prod deploy.

Other BUs read the published wheel from /Workspace/Shared/shared-libs/artifacts; only this repo's deploy principal writes there.
