# Databricks notebook source
# MAGIC %md
# MAGIC # Watchtower: daily cost report
# MAGIC Cost by BU tag from `system.billing.usage`, with untagged usage called out.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from watchtower.cost_rules import cost_by_tag, flag_untagged, top_spenders

usage = spark.sql("""
  SELECT usage_quantity AS usage_usd, custom_tags AS tags
  FROM system.billing.usage
  WHERE usage_date >= date_sub(current_date(), 1)
""")
rows = [r.asDict() for r in usage.collect()]

# COMMAND ----------

print("cost by business unit:", cost_by_tag(rows, "business_unit"))
print("top spenders:", top_spenders(rows, "business_unit"))
untagged = flag_untagged(rows, "business_unit")
print(f"untagged rows: {len(untagged)}")
