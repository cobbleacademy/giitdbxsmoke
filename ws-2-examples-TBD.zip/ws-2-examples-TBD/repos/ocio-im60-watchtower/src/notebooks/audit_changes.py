# Databricks notebook source
# MAGIC %md
# MAGIC # Watchtower: permission changes
# MAGIC Lists Unity Catalog permission changes from the audit log and logs them with the org logger.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from ocio_common.logging_setup import get_logger

log = get_logger("watchtower.audit")
changes = spark.sql("""
  SELECT event_time, user_identity.email AS changed_by, action_name
  FROM system.access.audit
  WHERE service_name = 'unityCatalog' AND action_name LIKE '%Permissions'
    AND event_date >= date_sub(current_date(), 1)
""")
for r in changes.collect():
    log.info("%s changed permissions via %s", r["changed_by"], r["action_name"])
