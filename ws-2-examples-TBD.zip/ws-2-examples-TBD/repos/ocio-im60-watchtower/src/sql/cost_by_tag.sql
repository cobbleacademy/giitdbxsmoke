CREATE OR REPLACE VIEW IDENTIFIER(:catalog || '.watchtower_gold.v_cost_by_bu') AS
SELECT usage_date, custom_tags['business_unit'] AS business_unit, SUM(usage_quantity) AS dbus
FROM system.billing.usage
GROUP BY usage_date, custom_tags['business_unit'];
