"""Small, pure rules the notebooks call. Rows are dicts: {"usage_usd": float, "tags": {str: str}}."""


def flag_untagged(rows, tag="segment"):
    """Rows that cannot be charged back because the tag is missing or empty."""
    return [r for r in rows if not (r.get("tags") or {}).get(tag)]


def cost_by_tag(rows, tag="segment"):
    totals = {}
    for r in rows:
        key = (r.get("tags") or {}).get(tag) or "untagged"
        totals[key] = round(totals.get(key, 0.0) + float(r["usage_usd"]), 2)
    return totals


def top_spenders(rows, tag="segment", n=3):
    return sorted(cost_by_tag(rows, tag).items(), key=lambda kv: kv[1], reverse=True)[:n]
