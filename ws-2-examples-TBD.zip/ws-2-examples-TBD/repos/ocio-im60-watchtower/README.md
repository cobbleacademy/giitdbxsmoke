# ocio-im60-watchtower

Watchtower: daily cost and audit reporting for the platform, built from system tables

- Org: `ocio`  |  BU: `im60`  |  Use case: `watchtower`
- Workspaces: `ocio-dev`, `ocio-test`, `ocio-prod`
- Deployed folder: `/Workspace/Shared/im60/watchtower` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the watchtower wheel
resources/                jobs.yml
src/watchtower/           cost_rules.py (pure Python)
src/notebooks/            daily_cost_report.py, audit_changes.py
src/sql/                  cost_by_tag.sql
tests/                    cost rule tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `ocio-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `ocio-test`; the `ocio-prod` environment needs an approver before the prod deploy.

Notebook-led use case: the notebooks do the reporting and call small, tested Python rules.
