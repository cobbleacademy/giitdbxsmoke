from watchtower.cost_rules import cost_by_tag, flag_untagged, top_spenders

ROWS = [
    {"usage_usd": 10.0, "tags": {"business_unit": "im50"}},
    {"usage_usd": 5.5, "tags": {"business_unit": "im60"}},
    {"usage_usd": 4.5, "tags": {"business_unit": "im50"}},
    {"usage_usd": 2.0, "tags": {}},
    {"usage_usd": 1.0, "tags": None},
]


def test_cost_by_tag_groups_and_rounds():
    assert cost_by_tag(ROWS, "business_unit") == {"im50": 14.5, "im60": 5.5, "untagged": 3.0}


def test_flag_untagged_finds_missing_and_empty_tags():
    assert len(flag_untagged(ROWS, "business_unit")) == 2


def test_top_spenders_orders_by_cost():
    assert top_spenders(ROWS, "business_unit", n=2) == [("im50", 14.5), ("im60", 5.5)]
