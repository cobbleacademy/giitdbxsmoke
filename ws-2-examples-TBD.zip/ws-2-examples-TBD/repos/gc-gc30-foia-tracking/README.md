# gc-gc30-foia-tracking

GC-30 FOIA tracking: request cases cleaned in a pipeline, with SLA breaches reported daily and reviewed in a notebook

- Org: `gc`  |  BU: `gc30`  |  Use case: `foia-tracking`
- Workspaces: `gc-dev`, `gc-test`, `gc-prod`
- Deployed folder: `/Workspace/Shared/gc30/foia-tracking` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the foia wheel (entry point: sla_report)
resources/                jobs.yml, pipelines.yml
src/foia/                 sla.py (pure Python), cli.py
src/notebooks/            breach_review.py
src/pipelines/            foia_cases.py
tests/                    SLA rule tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `gc-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `gc-test`; the `gc-prod` environment needs an approver before the prod deploy.

Business rules (SLA days) live in plain Python so they are tested without Spark and reused by the job and the notebook.
