from datetime import date

import pytest

from foia.sla import business_days_between, is_breached


def test_business_days_skip_weekends():
    assert business_days_between(date(2026, 10, 2), date(2026, 10, 7)) == 3


def test_end_before_start_is_rejected():
    with pytest.raises(ValueError):
        business_days_between(date(2026, 10, 7), date(2026, 10, 2))


def test_open_case_breaches_once_past_the_sla():
    assert is_breached(date(2026, 9, 1), None, 20, today=date(2026, 10, 15))
    assert not is_breached(date(2026, 10, 1), None, 20, today=date(2026, 10, 15))


def test_closed_case_uses_its_closing_date():
    assert not is_breached(date(2026, 9, 1), date(2026, 9, 15), 20, today=date(2026, 12, 1))
