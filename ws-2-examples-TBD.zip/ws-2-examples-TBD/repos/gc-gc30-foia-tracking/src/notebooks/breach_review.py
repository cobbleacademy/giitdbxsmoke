# Databricks notebook source
# MAGIC %md
# MAGIC # SLA breach review
# MAGIC Shows breached cases with the requester masked, using `gc_common.pii`.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from gc_common.pii import mask_email

breached = spark.sql(f"""
  SELECT c.case_id, c.requester_email
  FROM {catalog}.foia_silver.cases c JOIN {catalog}.foia_gold.sla_status s USING (case_id)
  WHERE s.breached
""").collect()
for r in breached:
    print(r["case_id"], mask_email(r["requester_email"]))
