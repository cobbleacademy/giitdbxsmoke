import argparse
from datetime import date

from foia.sla import is_breached


def sla_report(argv=None):
    from pyspark.sql import SparkSession

    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--sla_days", type=int, default=20)
    args = parser.parse_args(argv)
    spark = SparkSession.builder.getOrCreate()
    today = date.today()
    cases = spark.table(f"{args.catalog}.foia_silver.cases").collect()
    rows = [(c["case_id"], is_breached(c["opened"], c["closed"], args.sla_days, today)) for c in cases]
    spark.createDataFrame(rows, "case_id string, breached boolean").write.mode("overwrite").saveAsTable(f"{args.catalog}.foia_gold.sla_status")
