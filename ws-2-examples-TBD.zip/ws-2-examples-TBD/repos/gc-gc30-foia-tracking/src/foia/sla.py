from datetime import date, timedelta


def business_days_between(start: date, end: date) -> int:
    """Whole business days (Mon-Fri) from start up to, not including, end. Holidays are not modelled."""
    if end < start:
        raise ValueError("end is before start")
    days, d = 0, start
    while d < end:
        if d.weekday() < 5:
            days += 1
        d += timedelta(days=1)
    return days


def is_breached(opened: date, closed, sla_days: int, today: date) -> bool:
    """A case breaches when it took, or has so far taken, more than `sla_days` business days."""
    return business_days_between(opened, closed or today) > sla_days
