import dlt
from pyspark.sql import functions as F

CATALOG = spark.conf.get("catalog")


@dlt.table(name=f"{CATALOG}.foia_silver.cases", comment="FOIA cases with typed dates")
def cases():
    raw = spark.read.table(f"{CATALOG}.foia_bronze.cases_raw")
    return (
        raw.withColumn("opened", F.to_date("opened"))
        .withColumn("closed", F.to_date("closed"))
        .filter(F.col("case_id").isNotNull())
        .dropDuplicates(["case_id"])
    )
