# cmei-epo-doc-intake

EPO document intake: files land in a volume, Auto Loader registers them, and unsupported files are reported

- Org: `cmei`  |  BU: `epo`  |  Use case: `doc-intake`
- Workspaces: `cmei-dev`, `cmei-test`, `cmei-prod`
- Deployed folder: `/Workspace/Shared/epo/doc-intake` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the intake wheel
resources/                jobs.yml, pipelines.yml
src/intake/               parsing.py (pure Python, also used as a UDF)
src/pipelines/            intake_autoloader.py
src/notebooks/            intake_audit.py
tests/                    parsing tests
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `cmei-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `cmei-test`; the `cmei-prod` environment needs an approver before the prod deploy.

File-arrival use case: an Auto Loader pipeline plus a small audit notebook, with the filename rules in plain Python.
