# Databricks notebook source
# MAGIC %md
# MAGIC # Intake audit
# MAGIC Counts files by type and reports unsupported files.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from cmei_common.quality import not_null_rate

files = spark.table(f"{catalog}.intake_bronze.files")
rows = [r.asDict() for r in files.select("length").collect()]
assert not_null_rate(rows, "length") == 1.0, "some files have no size"
print("by type:", {r["doc_type"]: r["count"] for r in files.groupBy("doc_type").count().collect()})
unsupported = files.filter("NOT supported")
print(f"unsupported files: {unsupported.count()}")
