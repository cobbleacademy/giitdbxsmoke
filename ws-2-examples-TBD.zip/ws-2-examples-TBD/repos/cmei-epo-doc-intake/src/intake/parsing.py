import re

SUPPORTED = {"pdf", "docx", "txt"}
PATTERN = re.compile(r"^(?P<doc_type>[a-z]+)_(?P<doc_date>\d{8})_(?P<doc_id>[A-Za-z0-9]+)\.(?P<ext>[A-Za-z0-9]+)$")


def parse_filename(name):
    """<type>_<YYYYMMDD>_<id>.<ext> -> dict, or None when the name does not follow the convention."""
    m = PATTERN.match(name)
    if not m:
        return None
    parts = m.groupdict()
    parts["ext"] = parts["ext"].lower()
    return parts


def is_supported(name):
    parts = parse_filename(name)
    return bool(parts) and parts["ext"] in SUPPORTED


def doc_type(name):
    parts = parse_filename(name)
    return parts["doc_type"] if parts else "unknown"
