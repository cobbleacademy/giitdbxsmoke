import dlt
from pyspark.sql import functions as F

from intake.parsing import doc_type, is_supported

CATALOG = spark.conf.get("catalog")
doc_type_udf = F.udf(doc_type)
supported_udf = F.udf(is_supported, "boolean")


@dlt.table(name=f"{CATALOG}.intake_bronze.files", comment="Files that arrived in the landing volume")
def files():
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "binaryFile")
        .load(f"/Volumes/{CATALOG}/intake_bronze/landing/")
        .withColumn("file_name", F.element_at(F.split("path", "/"), -1))
        .withColumn("doc_type", doc_type_udf("file_name"))
        .withColumn("supported", supported_udf("file_name"))
        .select("path", "file_name", "doc_type", "supported", "modificationTime", "length")
    )
