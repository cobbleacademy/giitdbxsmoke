from intake.parsing import doc_type, is_supported, parse_filename


def test_parse_filename_follows_the_convention():
    assert parse_filename("memo_20261001_A12.PDF") == {"doc_type": "memo", "doc_date": "20261001", "doc_id": "A12", "ext": "pdf"}
    assert parse_filename("scan.pdf") is None


def test_supported_extensions_only():
    assert is_supported("memo_20261001_A12.pdf")
    assert not is_supported("memo_20261001_A12.exe")
    assert not is_supported("random.pdf")


def test_doc_type_falls_back_to_unknown():
    assert doc_type("letter_20261001_B7.docx") == "letter"
    assert doc_type("random.pdf") == "unknown"
