# cmei-aso-grants-reporting

ASO grants reporting: award data summarized by program, with overdue awards flagged for review

- Org: `cmei`  |  BU: `aso`  |  Use case: `grants-reporting`
- Workspaces: `cmei-dev`, `cmei-test`, `cmei-prod`
- Deployed folder: `/Workspace/Shared/aso/grants-reporting` in every workspace

## Layout

```
databricks.yml            bundle: dev, test, prod targets
pyproject.toml            builds the grants wheel
resources/                jobs.yml, pipelines.yml
src/grants/               reporting.py (Spark transforms)
src/jobs/                 refresh_summary.py (spark_python_task)
src/notebooks/            award_review.py
src/pipelines/            awards.py
tests/                    Spark transform tests
sample_data/              awards.csv
.github/workflows/        ci.yml, deploy.yml
```

## Work on it

1. Branch as `<ticket>-short-description` in your user Git folder in `cmei-dev`.
2. `PYTHONPATH=src pytest tests -q`, then `databricks bundle validate -t dev`.
3. Open a pull request: CI runs the tests and validates the bundle. Merge needs a human approval.
4. After the merge, `deploy.yml` deploys to `cmei-test`; the `cmei-prod` environment needs an approver before the prod deploy.

Mixes a Python script task, a notebook task and a pipeline in one weekly job.
