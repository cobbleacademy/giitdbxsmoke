import argparse

from pyspark.sql import SparkSession

from grants.reporting import summarize_awards

parser = argparse.ArgumentParser()
parser.add_argument("--catalog", required=True)
args = parser.parse_args()

spark = SparkSession.builder.getOrCreate()
awards = spark.table(f"{args.catalog}.grants_silver.awards")
summarize_awards(awards).write.mode("overwrite").saveAsTable(f"{args.catalog}.grants_gold.program_summary")
