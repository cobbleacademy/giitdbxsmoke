# Databricks notebook source
# MAGIC %md
# MAGIC # Overdue award review
# MAGIC Lists overdue awards for the weekly review. Uses `cmei_common` for the fiscal year label.

# COMMAND ----------

dbutils.widgets.text("catalog", "")
catalog = dbutils.widgets.get("catalog")

# COMMAND ----------

from datetime import date

from cmei_common.fiscal import fiscal_year
from grants.reporting import flag_overdue

today = date.today()
overdue = flag_overdue(spark.table(f"{catalog}.grants_silver.awards"), today.isoformat())
print(f"FY{fiscal_year(today)}: {overdue.count()} overdue awards")
display(overdue)
