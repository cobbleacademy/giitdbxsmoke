import dlt
from pyspark.sql import functions as F

CATALOG = spark.conf.get("catalog")


@dlt.table(name=f"{CATALOG}.grants_silver.awards", comment="Awards with typed amounts and dates")
def awards():
    raw = spark.read.table(f"{CATALOG}.grants_bronze.awards_raw")
    return raw.withColumn("amount", F.col("amount").cast("decimal(18,2)")).withColumn("due_date", F.to_date("due_date")).filter(F.col("award_id").isNotNull())
