from pyspark.sql import DataFrame, functions as F


def summarize_awards(df: DataFrame) -> DataFrame:
    """Award count and total amount per program."""
    return df.groupBy("program_code").agg(F.count("*").alias("awards"), F.sum(F.col("amount").cast("double")).alias("total_amount"))


def flag_overdue(df: DataFrame, as_of: str) -> DataFrame:
    """Awards past their due date that are not closed."""
    return df.filter((F.to_date("due_date") < F.to_date(F.lit(as_of))) & (F.lower("status") != "closed"))
