import os

from grants.reporting import flag_overdue, summarize_awards

SAMPLE = os.path.join(os.path.dirname(__file__), "..", "sample_data", "awards.csv")


def test_summarize_awards_by_program(spark):
    df = spark.read.option("header", True).csv(SAMPLE)
    result = {r["program_code"]: (r["awards"], r["total_amount"]) for r in summarize_awards(df).collect()}
    assert result == {"EDU": (2, 1250.5), "ENV": (2, 1300.0)}


def test_flag_overdue_ignores_closed_and_future(spark):
    df = spark.read.option("header", True).csv(SAMPLE)
    assert [r["award_id"] for r in flag_overdue(df, "2026-10-01").collect()] == ["A-1", "A-4"]
